% Input_and_Run.m is the file that you run, and it calls this file,
% which calls the following Matlab scripts:
%         1) PieceWiseLinearApproximation.m
%         2) DIphaseClassification.m  or  PredefinedDIphaseClassification.m
%   and   3) ExtractDIparameters.m
% Then, all files are saved



% Read input data files
tic
if(SKIP_FILE_READ==1)
    disp('-Skipped Read Data File.');
else
    for file_index = 1:length(FILE_NAME_INPUT)

        FILE_NAME = FILE_NAME_INPUT{file_index};
        disp(['-Begin Read Data File ', FILE_NAME]);

        M_new = dlmread(FILE_NAME, INPUT_FILE_DELIMITER, FIRST_DATA_ROW - 1, 0);
        Time_new = M_new(:, TIME_COLUMN) * TIME_CONVERSION_FACTOR;

        % Structure of length history data, M:
        % 1st column = Time values, 2nd column = Length values
        for LengthColIndex = MT_LENGTH_COLUMN_INDICES
            if( file_index==1 && LengthColIndex==MT_LENGTH_COLUMN_INDICES(1) ) 
                % For first file & first length data column only
                M = [Time_new, M_new(:, LengthColIndex)];
                Time = M(:, 1);
            else
                % Stitch length histories from all subsequent data columns and files to M
                Time_end = Time(end);
                This_Time_new = Time_new + Time_end + 11*max(MIN_SEGMENT_DURATION_INPUT); %Add time shift for next length history times
                %Add buffer between sampled length history data (negative length values for separations)
                M = [M;...
                    [(Time_end + max(MIN_SEGMENT_DURATION_INPUT)), -max(MAX_ERROR_TOLERANCE_INPUT)];...
                    [(Time_end + 10*max(MIN_SEGMENT_DURATION_INPUT)), -max(MAX_ERROR_TOLERANCE_INPUT)];...
                    [This_Time_new, M_new(:, LengthColIndex)]];
                Time = M(:, 1);
            end
        end

        disp('--File Read Completed.');
    end
end
toc

%for MT_LENGTH_COLUMN_INDEX = MT_LENGTH_COLUMN_INDICES
if(SKIP_FILE_READ==0)
    MT_length = M(:, 2);
end

for MIN_SEGMENT_DURATION = MIN_SEGMENT_DURATION_INPUT
    for MAX_ERROR_TOLERANCE = MAX_ERROR_TOLERANCE_INPUT
        for FLATSTUT_MAX_SEGMENTHEIGHT_THRESHOLD = FLATSTUT_MAX_SEGMENTHEIGHT_THRESHOLD_INPUT
            for FLATSTUT_MAX_SEGMENTSLOPE_THRESHOLD = FLATSTUT_MAX_SEGMENTSLOPE_THRESHOLD_INPUT
                for NUC_HEIGHT_THRESHOLD = NUC_HEIGHT_THRESHOLD_INPUT

                    % Create Output Directory
                    % Use input filename to create output directory name
                    % Remove input filename suffix
                    filename = sprintf('%s',char(FILE_NAME));
                    filename_prefix = split(filename,".");
                    filename_prefix = filename_prefix{1};
                    % Remove input file directories
                    filename_prefix = split(filename_prefix, "/"); % for Non-Windows style directory
                    FILE_NAME = filename_prefix{length(filename_prefix)};
                    filename_prefix = split(filename_prefix, "\"); % for Windows style directory
                    FILE_NAME = filename_prefix{length(filename_prefix)};
                    % Append time stamp to input filename                
                    this_datetime = datetime;
                    DateTimeString = sprintf('_%.0f_%02dh%.0fmin%.0fsec', ...
                        yyyymmdd(this_datetime), hour(this_datetime), ...
                        minute(this_datetime), round(second(this_datetime)));
                    % Create output directory name
                    if( sum(KMEANS_DIAGNOSTIC_AllFLAG + KMEANS_DIAGNOSTIC_PosSlopeFLAG + KMEANS_DIAGNOSTIC_NegSlopeFLAG) == 0 )
                        Ouput_Dir_name = "STADIA_Output_for_" + FILE_NAME + DateTimeString;
                        mkdir(Ouput_Dir_name);
                    end
                    original_dir = pwd;



                    % Segment Length History Plot in DI data
                    % Segmentation via a piecewise linear approximation
                    disp('-Begin Segmentation Stage');
                    PieceWiseLinearApproximation_2021_10_22
                    disp('--Segmentation Stage Completed.');
                    toc

                    % Classify each segment into DI Phases
                    disp('-Begin Classification Stage');
                    % Classify DI phases using k-means
                        DIphaseClassification_2021_10_22

    %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %
    %  %  % Transfer Learning Options to be added in next STADIA Version %  %  %  
    %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %   
    %
    %       %%%  See "DIphaseClassification" for details. Code may exist for saving
    %       %%%  values for benchmark purposes
    %
    %                 if(SET_BENCHMARK_CLASSES==1)
    %                     % Classify DI phases using k-means
    %                     DIphaseClassification_2019_07_09
    %                 else
    %                     % Classify DI phases using benchmark info
    %                     PredefinedDIphaseClassification_2017_07_29
    %                 end
    %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  %  

                    toc

                    % Continue only in automated mode
                    if((KMEANS_DIAGNOSTIC_AllFLAG + KMEANS_DIAGNOSTIC_PosSlopeFLAG + KMEANS_DIAGNOSTIC_NegSlopeFLAG) == 0)

                        disp('--Classification Stage Complete');
                        disp(' ');

                        % Extract DI parameters
                        disp('-Begin Phase and Transition Analysis Stage');
                        ExtractDIparameters_2021_10_22
                        disp('--Phase and Transition Analysis Stage Complete');
                        disp(' ');
                        toc

                        % Move to output directory to save files
                        cd(Ouput_Dir_name);

                        writetable(Export_Table1, 'DIsegmentPhaseData.txt',...
                            'Delimiter','\t');
        %                 if(SET_BENCHMARK_CLASSES == 1)
        %                     writetable(Benchmark_Classes_Info_table,...
        %                         [FILE_NAME '_BenchmarkClassificationInfo.dat'],...
        %                         'Delimiter',',');
        %                 end
                        writetable(Export_Table2, 'DI_parameters_output.txt', ...
                            'Delimiter','\t')
                        writetable(Export_Table3, 'Abrupt_Catastrophe_output.txt', ...
                            'Delimiter','\t')
                        writetable(Export_Table4, 'Abrupt_Rescue_output.txt', ...
                            'Delimiter','\t')
                        writetable(Export_Table5, 'Transitional_Catastrophe_output.txt', ...
                            'Delimiter','\t')
                        writetable(Export_Table6, 'Transitional_Rescue_output.txt', ...
                            'Delimiter','\t')
                        writetable(Export_Table7, 'Interupted_Growth_output.txt', ...
                            'Delimiter','\t')
                        writetable(Export_Table8, 'Interupted_Shortening_output.txt', ...
                            'Delimiter','\t')

                        if SAVE_FIG_1 == 1 && PLOT_FIG_1 == 1
                            fig1filename = sprintf('PWLinearFit_Tol%d',MAX_ERROR_TOLERANCE);
                            savefig(fig1handle ,fig1filename)
                            print(fig1handle,'-dpng','-r0', fig1filename);
                            close(fig1handle);
                        end
                        if SAVE_FIG_2 == 1 && PLOT_FIG_3 == 1
                            fig2filename = sprintf('PosNegSlopeClusterResults');
                            savefig(fig2handle ,fig2filename)
                            print(fig2handle,'-dpng','-r0', fig2filename);
                            close(fig2handle);
                        end
                        if SAVE_FIG_3 == 1 && PLOT_FIG_3 == 1
                            fig3filename = sprintf('DIPhaseClassification');
                            savefig(fig3handle ,fig3filename)
                            print(fig3handle,'-dpng','-r0', fig3filename);
                            close(fig3handle);
                        end
                        if SAVE_FIG_4 == 1 && PLOT_FIG_4 == 1
                            fig4filename = sprintf('DIPhasesOnLengthHistory');
                            savefig(fig4handle ,fig4filename)
                            print(fig4handle,'-dpng','-r0', fig4filename);
                            close(fig4handle);
                        end
                        if SAVE_FIG_5 == 1 && PLOT_FIG_5 == 1
                            fig5filename = sprintf('AvgDIMeasurements');
                            savefig(fig5handle ,fig5filename)
                            print(fig5handle,'-dpng','-r0', fig5filename);
                            close(fig5handle);
                        end
                        if SAVE_FIG_6 == 1 && PLOT_FIG_6 == 1
                            fig6filename = sprintf('TotDIMeasurements');
                            savefig(fig6handle ,fig6filename)
                            print(fig6handle,'-dpng','-r0', fig6filename);
                            close(fig6handle);
                        end
                        if SAVE_FIG_7 == 1 && PLOT_FIG_7 == 1
                            fig7filename = sprintf('DIPhaseChangeResults');
                            savefig(fig7handle ,fig7filename)
                            print(fig7handle,'-dpng','-r0', fig7filename);
                            close(fig7handle);
                        end

                        % Move back to the previous directory
                        cd(original_dir);
                    end

                    if SAVE_MATLAB_WORKSPACE == 1
                        save(['DI_parameters_output_' FILE_NAME DateTimeString], ...
                            '-regexp', '^(?!(M|Time|MT_length)$).')
                    end

                end
            end
        end
    end
end

